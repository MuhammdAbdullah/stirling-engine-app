// Preload script for Matrix Stirling Engine
// This script runs in a secure context and exposes safe APIs to the renderer

const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electronAPI', {
    // Serial port communication
    getAvailablePorts: () => ipcRenderer.invoke('get-available-ports'),
    autoConnectStirling: () => ipcRenderer.invoke('auto-connect-stirling'),
    openAdminWindow: () => ipcRenderer.invoke('open-admin-window'),
    
    // Data handling - receives parsed data from worker thread
    onStirlingData: (callback) => {
        ipcRenderer.on('stirling-data', (event, data) => {
            callback(event, data);
        });
    },
    onRawData: (callback) => {
        ipcRenderer.on('raw-data', callback);
    },
    onConnectionStatus: (callback) => {
        ipcRenderer.on('connection-status', callback);
    },
    onSentCommand: (callback) => {
        ipcRenderer.on('sent-command', callback);
    },
    // Heater control
    setHeater: (value) => ipcRenderer.invoke('set-heater', value),
    setHeaterMode: (mode) => ipcRenderer.invoke('set-heater-mode', mode),
    setHardwareReady: (value) => ipcRenderer.invoke('set-hardware-ready', value),
    // Aux control (0-100%)
    setAux: (value) => ipcRenderer.invoke('set-aux', value),
    // Calibration - sends data with label M and value 1
    sendCalibration: () => ipcRenderer.invoke('send-calibration'),
    // Zero calibration - sends data with label Z and value 1
    sendZeroCalibration: () => ipcRenderer.invoke('send-zero-calibration'),
    // Calibration done - sends data with label N and value 1
    sendCalibrationDone: () => ipcRenderer.invoke('send-calibration-done'),
    getConnectionStatus: () => ipcRenderer.invoke('get-connection-status'),

    // CSV saving
    saveCsv: (filePath, rows) => ipcRenderer.invoke('save-csv', { filePath, rows }),
    chooseCsvPath: () => ipcRenderer.invoke('choose-csv-path'),
    
    // Remove listeners to prevent memory leaks
    removeAllListeners: (channel) => {
        ipcRenderer.removeAllListeners(channel);
    }
});
